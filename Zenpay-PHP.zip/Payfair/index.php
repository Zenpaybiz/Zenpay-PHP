<HTML>
<HEAD>

<script type="text/javascript" src="js/bootstrap_theme.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>

<link href="css/bootstrap-theme.min.css" rel="stylesheet" />
<link href="css/bootstrap.min.css" rel="stylesheet" />


<title>Payment Service Provider | Merchant Accounts</title>
<style>
.has-success .form-control, .has-success .control-label, .has-success .radio, .has-success .checkbox, .has-success .radio-inline, .has-success .checkbox-inline {
	color: #1cb78c !important;
}
.has-success .help-block {
	color: #1cb78c !important;
	border-color: #1cb78c !important;
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #1cb78c;
}
.has-error .form-control, .has-error .help-block, .has-error .control-label, .has-error .radio, .has-error .checkbox, .has-error .radio-inline, .has-error .checkbox-inline {
	color: #f0334d;
	border-color: #f0334d;
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #f0334d;
}
table {
	color: #333; /* Lighten up font color */
	font-family: "Raleway", Helvetica, Arial, sans-serif;
	font-weight: bold;
	width: 640px;
	border-collapse: collapse;
	border-spacing: 0;
}
td, th {
	border: 1px solid #CCC;
	height: 30px;
} /* Make cells a bit taller */
th {
	background: #F3F3F3; /* Light grey background */
	font-weight: bold; /* Make sure theyre bold */
	font-color: #1cb78c !important;
}
td {
	background: #FAFAFA; /* Lighter grey background */
	text-align: left;
	padding: 2px;/* Center our text */
}
label {
	font-weight: normal;
	display: block;
}
</style>
</HEAD>
<BODY>
<form class="form-horizontal" action="index.php" method="post"> 
  
  <div class="container cs-border-light-blue">
    <div class="row pad-top"></div>
    <div class="equalheight row" style="padding-top: 10px;">
      <div id="cs-main-body" class="cs-text-size-default pad-bottom">
        <div class="col-sm-9  equalheight-col pad-top">
          <div style="padding-bottom: 50px;">
            <h1>PAYFAIR</h1>
            <label class="control-label col-sm-4">INTEGRATION TYPE</label>
                      <div class="col-sm-8">
                      <select class="form-control" id="integrationtype" name="integrationtype">
						<option value="" selected>Select TYPE</option>
                          <option value="https://pay.payfair.in//v2/paymentrequest">NON-Seamless</option>
                          <option value="https://pay.payfair.in//v2/paymentseamlessrequest">S2S</option>
                          <option value="https://pay.payfair.in/.com/v2/paymentrequest">Non-Seamless-Selective-paymode</option>
                          </select>
                    </div>
            <div class="row">
              <div class="col-sm-12">
                <legend>Transaction Details</legend>
                
                    <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">API KEY</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="api_key" id="api_key" value="" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">SALT</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="salt" id="salt" value="" />
					 </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">return_url</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="return_url" id="return_url" value="http://localhost/Payfair/return_page.php" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">return_url_success</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="return_url_success" id="return_url_success" value="" />
					 </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">return_url_failure</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="return_url_failure" id="return_url_failure" value="" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">mode</label>
                      <div class="col-sm-8">
                      <select class="form-control" id="mode" name="mode">
						<option value="" selected>Select MODE</option>
                          <option value="TEST">TEST</option>
                          <option value="LIVE">LIVE</option> 
                          </select>
                    </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">order_id</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="order_id" id="order_id" value="<?php echo(rand())?>" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">amount</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="amount" id="amount" value="1000" />
					 </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">currency</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="currency" id="currency" value="INR" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">description</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="description" id="description" value="TESTING SIMULATOR" />
					 </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">name</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="name" id="name" value="MANDY" />					  
				
					  </div>
                    </div>
                  </div>

                  <!-- <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">Merchant Key</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="merchant_key" id="merchant_key" value="" />
					 </div>
                    </div>-->
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">email</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="email" id="email" value="mandy@gmail.com" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">phone</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="phone" id="phone" value="7541236589" />
					 </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">address1</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="address1" id="address1" value="" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">address2</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="address2" id="address2" value="" />
					 </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">city</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="city" id="city" value="Bangalore" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">state</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="state" id="state" value="Karnataka" />
					 </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">zip_code</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="zip_code" id="zip_code" value="560001" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">country</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="country" id="country" value="IND" />
					 </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">udf1</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="udf1" id="udf1" value="" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">udf2</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="udf2" id="udf2" value="" />
					 </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">udf3</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="udf3" id="udf3" value="" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">udf4</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="udf4" id="udf4" value="" />
					 </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">udf5</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="udf5" id="udf5" value="" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">split_info</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="split_info" id="split_info" value="" />
					 </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">split_enforce_strict</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="split_enforce_strict" id="split_enforce_strict" value="n" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">percent_tdr_by_user</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="percent_tdr_by_user" id="percent_tdr_by_user" value="" />
					 </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">show_conven_fee</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="show_convenience_fee" id="show_convenience_fee" value="" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">payment_options</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="payment_options" id="payment_options" value="" />
					 </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">allowed_bank_codes</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="allowed_bank_codes" id="allowed_bank_codes" value="" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">allowed_bins</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="allowed_bins" id="allowed_bins" value="" />
					 </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">offer_code</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="offer_code" id="offer_code" value="" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">allowed_emi_tenure</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="allowed_emi_tenure" id="allowed_emi_tenure" value="" />
					 </div>
                    </div>
                  </div>
                  </div>
                </div>
               <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">timeout_duration</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="timeout_duration" id="timeout_duration" value="" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">product_details</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="product_details" id="product_details" value="" />
					 </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">payment_page_display_text</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="payment_page_display_text" id="payment_page_display_text" value="" />					  
				
					           </div>
                    </div>
                  </div>
                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">bank Code</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="bank_code" id="bank_code" value="" />					  
				
					           </div>
                    </div>
                  </div>

                

            <div class="row">
              <div class="col-sm-12">
                <div class="form-group">
                  <div class="col-sm-10 col-sm-offset-2">
                    <button class="btn btn-primary btn-lg"
											style="display: inline-block; vertical-align: middle; vert-align: middle; float: none;" name="submit">Checkout</button>
      
  </div>
</form>
</BODY>
</HTML>



<?php




if(isset($_POST['submit'])){



$pg_request_url=$_POST['integrationtype'];

$request = array();
$request['api_key']=$_POST['api_key'];
$request['return_url']=$_POST['return_url'];
$request['return_url_success']=$_POST['return_url_success'];
$request['return_url_failure']=$_POST['return_url_failure'];
$request['mode']=$_POST['mode'];
$request['order_id']=$_POST['order_id'];
$request['amount']=$_POST['amount'];
$request['currency']=$_POST['currency'];
$request['description']=$_POST['description'];
$request['name']=$_POST['name'];
$request['email']=$_POST['email'];
$request['phone']=$_POST['phone'];
$request['address1']=$_POST['address1'];
$request['address2']=$_POST['address2'];
$request['city']=$_POST['city'];
$request['state']=$_POST['state'];
$request['zip_code']=$_POST['zip_code'];
$request['country']=$_POST['country'];
$request['udf1']=$_POST['udf1'];
$request['udf2']=$_POST['udf2'];
$request['udf3']=$_POST['udf3'];
$request['udf4']=$_POST['udf4'];
$request['udf5']=$_POST['udf5'];
$request['bank_code']=$_POST['bank_code'];
$request['split_info']=$_POST['split_info'];
$request['split_enforce_strict']=$_POST['split_enforce_strict'];
$request['percent_tdr_by_user']=$_POST['percent_tdr_by_user'];
$request['show_convenience_fee']=$_POST['show_convenience_fee'];
$request['payment_options']=$_POST['payment_options'];
$request['allowed_bank_codes']=$_POST['allowed_bank_codes'];
$request['allowed_bins']=$_POST['allowed_bins'];
$request['offer_code']=$_POST['offer_code'];
$request['allowed_emi_tenure']=$_POST['allowed_emi_tenure'];
$request['timeout_duration']=$_POST['timeout_duration'];
$request['product_details']=$_POST['product_details'];
$request['payment_page_display_text']=$_POST['payment_page_display_text'];


//ksort($request);

$salt = $_POST['salt'];

$hash = hashcreate($request,$salt);


$output = '<form id="payForm" action="'.$pg_request_url.'" method="post">';
        foreach ($request as $key => $value) {
            $output .= '<input type="hidden" name="' . $key . '" value="' . $value . '">' . "\n";
            $output .= '<input type="hidden" name="hash" value="' . $hash. '">' . "\n";
        }
        $output .= '</form><script> document.getElementById("payForm").submit(); </script><h2>Redirecting...</h2>';
        echo $output;


}


function hashcreate($data,$salt){
  ksort($data);
  $testing = $salt;
  foreach($data as $key => $value){
    if(strlen($value) > 0){
      $testing .= '|'.trim($value);
  }
  if(strlen($testing) > 0){
    $hash = strtoupper(hash("sha512",$testing));
  }
}
  return $hash;
}



?>